# CameraPreView
Android camera 和camera2 示例：实现照相功能、前后摄像头切换、预览帧抓取等
使用 gradle-2.4-all.zip
